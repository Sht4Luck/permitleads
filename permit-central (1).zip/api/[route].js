import crypto from 'node:crypto';
import Stripe from 'stripe';
import { sql, ensure, BASE, TRADES, isActive, sendBatch, emailShell } from '../lib/core.js';

const cleanZips = z => [...new Set((z || []).map(s => String(s).trim()).filter(s => /^\d{5}$/.test(s)))];
const cleanTrades = t => (t || []).filter(x => TRADES.includes(x));
const E = process.env;

export default async function handler(req, res) {
  if (req.query.route === 'health') return res.json({ ok: true, database: !!(E.DATABASE_URL || E.POSTGRES_URL), stripe: !!E.STRIPE_SECRET_KEY, resend: !!E.RESEND_API_KEY, baseUrl: E.BASE_URL || null });
  try { await ensure(); } catch (e) { return res.status(500).json({ error: e.message }); }
  const route = req.query.route, b = req.body || {};
  try {
    if (route === 'signup') {
      if (!/^\S+@\S+\.\S+$/.test(b.email || '')) return res.status(400).json({ error: 'Please enter a valid email.' });
      const trades = cleanTrades(b.trades);
      if (!trades.length) return res.status(400).json({ error: 'Pick at least one trade.' });
      const token = crypto.randomBytes(16).toString('hex'), now = Date.now();
      const r = await sql`INSERT INTO contractors(email,company,trades,zips,token,trial_ends,created) VALUES(${b.email.toLowerCase()},${b.company || ''},${JSON.stringify(trades)}::jsonb,${JSON.stringify(cleanZips(b.zips))}::jsonb,${token},${now + (+E.TRIAL_DAYS || 7) * 864e5},${now}) ON CONFLICT (email) DO NOTHING RETURNING id`;
      if (!r.length) return res.status(409).json({ error: 'That email is already signed up. Check your inbox for your dashboard link.' });
      await sendBatch([{ to: b.email, subject: 'Welcome to Permit Central', html: emailShell(`<h2>You're in.</h2><p>Your first list arrives tomorrow morning. Free, no card.</p><p><a href="${BASE}/dashboard?t=${token}">Open your dashboard</a></p>`) }]);
      return res.json({ token });
    }
    const [c] = await sql`SELECT * FROM contractors WHERE token=${req.query.t || ''}`;
    if (!c) return res.status(401).json({ error: 'Link not recognized. Use the link from your email.' });

    if (route === 'me') { const { stripe_customer, ...rest } = c; return res.json({ ...rest, active: isActive(c) }); }
    if (route === 'settings') {
      await sql`UPDATE contractors SET trades=${JSON.stringify(cleanTrades(b.trades))}::jsonb, zips=${JSON.stringify(cleanZips(b.zips))}::jsonb WHERE id=${c.id}`;
      return res.json({ ok: true });
    }
    if (route === 'permits') {
      if (!isActive(c)) return res.status(402).json({ error: 'Your free trial has ended.' });
      const days = Math.min(+req.query.days || 30, 60), cutoff = Date.now() - days * 864e5, day = new Date(cutoff).toISOString().slice(0, 10);
      const rows = await sql`SELECT number,type,description,address,zip,value,issued,tags,first_seen FROM permits WHERE (first_seen > ${cutoff} OR issued >= ${day}) AND jsonb_array_length(tags) > 0 ORDER BY issued DESC NULLS LAST, first_seen DESC LIMIT 1000`;
      return res.json(rows.filter(p => p.tags.some(t => c.trades.includes(t)) && (!c.zips.length || c.zips.includes(p.zip)))
        .map(p => ({ ...p, first_seen: Number(p.first_seen), value: p.value ? Number(p.value) : null })));
    }
    const stripe = new Stripe(E.STRIPE_SECRET_KEY);
    if (route === 'checkout') {
      const s = await stripe.checkout.sessions.create({ mode: 'subscription', line_items: [{ price: E.STRIPE_PRICE_ID, quantity: 1 }],
        customer_email: c.email, client_reference_id: c.token, success_url: `${BASE}/dashboard?t=${c.token}&paid=1`, cancel_url: `${BASE}/dashboard?t=${c.token}` });
      return res.json({ url: s.url });
    }
    if (route === 'portal' && c.stripe_customer) {
      const s = await stripe.billingPortal.sessions.create({ customer: c.stripe_customer, return_url: `${BASE}/dashboard?t=${c.token}` });
      return res.json({ url: s.url });
    }
    res.status(404).json({ error: 'not found' });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Something went wrong. Please try again.' }); }
}
