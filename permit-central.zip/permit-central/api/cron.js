import { runDaily } from '../lib/core.js';
export default async function handler(req, res) {
  if (process.env.CRON_SECRET && req.headers.authorization !== `Bearer ${process.env.CRON_SECRET}`) return res.status(401).json({ error: 'unauthorized' });
  try { res.json(await runDaily()); } catch (e) { console.error(e); res.status(500).json({ error: e.message }); }
}
