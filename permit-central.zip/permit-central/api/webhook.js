import Stripe from 'stripe';
import { sql, ensure } from '../lib/core.js';
export const config = { api: { bodyParser: false } };
export default async function handler(req, res) {
  const chunks = []; for await (const c of req) chunks.push(c);
  let ev;
  try { ev = new Stripe(process.env.STRIPE_SECRET_KEY).webhooks.constructEvent(Buffer.concat(chunks), req.headers['stripe-signature'], process.env.STRIPE_WEBHOOK_SECRET); }
  catch (e) { return res.status(400).send(e.message); }
  await ensure(); const o = ev.data.object;
  if (ev.type === 'checkout.session.completed') await sql`UPDATE contractors SET status='active', stripe_customer=${o.customer} WHERE token=${o.client_reference_id}`;
  if (ev.type === 'customer.subscription.deleted') await sql`UPDATE contractors SET status='canceled' WHERE stripe_customer=${o.customer}`;
  res.json({ received: true });
}
