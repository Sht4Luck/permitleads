# Permit Central: deploy on Vercel

1. Push this folder to a GitHub repo, then **Vercel > Add New > Project > Import**. (Or run `npx vercel` here.)
2. **Storage tab > Create Database > Neon (Postgres)**. This adds `DATABASE_URL` automatically. Tables are created on first request.
3. **Settings > Environment Variables**: add everything in `.env.example`.
   - Stripe: create a $99/month recurring Price, copy its `price_...` id. Enable the Customer Portal in Stripe settings.
   - Stripe webhook: endpoint `https://YOUR-APP.vercel.app/api/webhook`, events `checkout.session.completed` and `customer.subscription.deleted`. Copy the signing secret.
   - Resend: verify your sending domain, then set `FROM_EMAIL`.
4. Redeploy. The daily job runs at 14:00 UTC (6 or 7 AM Pacific) via `vercel.json`.
5. **First test**: run once by hand to load permits (the first run is a silent baseline, no emails):
   `curl -H "Authorization: Bearer YOUR_CRON_SECRET" https://YOUR-APP.vercel.app/api/cron`
   Then check the Neon table `permits` and adjust field matching in `lib/core.js` (`ingest`, `tagPermit`) to Bend's real columns.

Add trades: edit `TRADES`/`LABEL` and `tagPermit` in `lib/core.js`, plus the `T` list in both HTML files.
